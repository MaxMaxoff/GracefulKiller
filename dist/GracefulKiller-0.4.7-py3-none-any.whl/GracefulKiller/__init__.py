try:
    from GracefulKiller.GracefulKiller import GracefulKiller, Loop
except:
    from src.GracefulKiller.GracefulKiller import GracefulKiller, Loop
