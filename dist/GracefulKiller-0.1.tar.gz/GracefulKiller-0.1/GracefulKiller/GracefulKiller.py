#!/.venv/bin/python
# -*- coding: utf-8 -*-
import signal

# process SIGTERM and SIGINT signals gracefully
class GracefulKiller:
    def __init__(self):
        self.kill_now = False
        signal.signal(signal.SIGINT, self.exit_gracefully)
        signal.signal(signal.SIGTERM, self.exit_gracefully)

    def exit_gracefully(self, signum, frame):
        self.kill_now = True
